// Knob
let device_id = null;
let _ENDPOINT =  'https://6.iottalk.tw';
let password = ''

function set_device_id0(d_id){
    device_id = d_id;
    csmapi.set_endpoint(_ENDPOINT);   
}

$(function () {
    // Init vars
    var knobs = $('.knob-container');
    var knobVal = [];
    knobVal.length = knobs.length;

    // Init knob appearance
    knobs.knobKnob({
        startDeg: -45,
        degRange: 270,
        initVal: 0.0,
        numColorbar: 31,
    });

    // Check knob val updated or not
    function knobChecker() {
        // Check update
        for(var i=0; i<knobs.length; ++i)
            if( knobVal[i] !== $(knobs[i]).val() ) {
                knobVal[i] = $(knobs[i]).val().toString();
                csmapi.push(device_id, '',$(knobs[i]).attr('role'), [parseFloat(knobVal[i])]);
            }
    }
    setInterval(knobChecker, 250);
});